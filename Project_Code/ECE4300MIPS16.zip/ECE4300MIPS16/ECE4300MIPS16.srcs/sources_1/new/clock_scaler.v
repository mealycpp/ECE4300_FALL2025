`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/09/2025 10:32:46 PM
// Design Name: 
// Module Name: clock_scaler
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clock_scaler(
    input wire clk_in,
    output reg clk_out
);

    reg [31:0] counter; // Counter for clock cycles

    initial begin
        clk_out = 0;
        counter = 0;
    end

    always @(posedge clk_in) begin
        counter <= + 1;
        clk_out = counter[25];
        if (counter[31:0] == 32'hFFFF) begin
            counter <= 32'h0000;
        end
    end

endmodule
