`timescale 1ns / 1ps //ALU CONTROL NO CHANGES MADE
// Verilog project: Verilog code for 32-bit MIPS Processor
// Submodule: ALU Control Unit in Verilog 
 module ALUControl( ALU_Control, ALUOp, Function);  
 output reg[4:0] ALU_Control;  
 input [1:0] ALUOp;  
 input [5:0] Function;  
 wire [7:0] ALUControlIn;  
 assign ALUControlIn = {ALUOp,Function};  
 always @(ALUControlIn)  
 casex (ALUControlIn)  
  8'b11xxxxxx: ALU_Control=5'b00000;  
  8'b10xxxxxx: ALU_Control=5'b00100;  
  8'b01xxxxxx: ALU_Control=5'b00001;  
  8'b00000000: ALU_Control=5'b00000;  
  8'b00000001: ALU_Control=5'b00001;  
  8'b00000010: ALU_Control=5'b00010;  
  8'b00000011: ALU_Control=5'b00011;  
  8'b00000100: ALU_Control=5'b00100;  
  default: ALU_Control=5'b00000;  
  endcase  
 endmodule  
// Verilog code for JR control unit
module JR_Control( 
       input[1:0] alu_op, 
       input[5:0] funct,
       output JRControl
    );
assign JRControl = ({alu_op,funct}==8'b00001000) ? 1'b1 : 1'b0;
endmodule 
