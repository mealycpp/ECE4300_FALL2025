module alu(
    input  [31:0] a,
    input  [31:0] b,
    input  [4:0]  alu_control,
    output reg [31:0] result,
    output zero
);
always @(*) begin
    case (alu_control)
        5'b00000: result = a + b;                     // add / addi / lw / sw
        5'b00001: result = a - b;                     // sub / beq
        5'b00010: result = a & b;                     // and (if used)
        5'b00011: result = a | b;                     // or  (if used)
        5'b00100: result = (a < b) ? 32'd1 : 32'd0;   // slt (if used)
        default:  result = a + b;
    endcase
end
assign zero = (result == 32'd0) ? 1'b1 : 1'b0;
endmodule
