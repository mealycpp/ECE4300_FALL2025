`timescale 1ns / 1ps
// Verilog code for 32-bit single cycle MIPS CPU  
module mips_32(
    input clk,
    input reset,  
    output [31:0] pc_out,
    output [31:0] alu_result,
    output [31:0]reg3,
    output [31:0]reg4,
    output [31:0]reg5,
    output [31:0]reg2  
);  

    // Program Counter
    reg [31:0] pc_current;  
    wire signed [31:0] pc_next, pc4;  

    // Instruction
    wire [31:0] instr;  

    // Control signals
    wire [1:0] reg_dst, mem_to_reg, alu_op;  
    wire jump, branch, mem_read, mem_write, alu_src, reg_write;  
    wire sign_or_zero;

    // Register file wires
    wire [4:0] reg_write_dest;  
    wire [31:0] reg_write_data;  
    wire [4:0] reg_read_addr_1;  
    wire [31:0] reg_read_data_1;  
    wire [4:0] reg_read_addr_2;  
    wire [31:0] reg_read_data_2;  

    // ALU and immediate wires
    wire [31:0] sign_ext_im, zero_ext_im, imm_ext, read_data2;  
    wire JRControl;  
    wire [4:0] ALU_Control;  
    wire [31:0] ALU_out;  
    wire zero_flag;  
    wire signed [31:0] im_shift_1, PC_j, PC_beq, PC_4beq, PC_4beqj, PC_jr;  
    wire beq_control;  
    wire [27:0] jump_shift_1;  
    wire [31:0] mem_read_data;  
    wire [31:0] no_sign_ext;  

    // Program Counter logic
    always @(posedge clk or posedge reset) begin   
        if (reset)   
            pc_current <= 32'd0;  
        else  
            pc_current <= pc_next;  
    end  

    // PC + 4
    assign pc4 = pc_current + 32'd4;  

    // Instruction memory
    instr_mem instruction_memory(
        .pc(pc_current),
        .instruction(instr)
    );  

    // Jump shift left by 1
    assign jump_shift_1 = {instr[25:0], 2'b00}; 

    // Control unit
    control control_unit(
        .reset(reset),
        .opcode(instr[31:26]),
        .reg_dst(reg_dst),
        .mem_to_reg(mem_to_reg),
        .alu_op(alu_op),
        .jump(jump),
        .branch(branch),
        .mem_read(mem_read),
        .mem_write(mem_write),
        .alu_src(alu_src),
        .reg_write(reg_write),
        .sign_or_zero(sign_or_zero)
    );  

    // Multiplexer reg_dest
    assign reg_write_dest = (reg_dst == 2'b10) ? 5'b11111 : ((reg_dst == 2'b01) ? instr[15:11] : instr[20:16]);  

    // Register file
    assign reg_read_addr_1 = instr[25:21]; // instruction bits 12 to 10 specify source register for R type
    assign reg_read_addr_2 = instr[20:16]; // instruction bits 9 to 7 specify target register for R type

    register_file reg_file(
        .clk(clk),
        .rst(reset),
        .reg_write_en(reg_write),
        .reg_write_dest(reg_write_dest),
        .reg_write_data(reg_write_data),
        .reg_read_addr_1(reg_read_addr_1),
        .reg_read_data_1(reg_read_data_1),
        .reg_read_addr_2(reg_read_addr_2),
        .reg_read_data_2(reg_read_data_2),
        .reg3(reg3),
        .reg4(reg4),
        .reg5(reg5),
        .reg2(reg2)
    );  

    // Sign extend
    assign sign_ext_im = {{16{instr[15]}}, instr[15:0]};  
    assign zero_ext_im = {{16{1'b0}}, instr[15:0]};  
    assign imm_ext = (sign_or_zero == 1'b1) ? sign_ext_im : zero_ext_im;  

    // JR control
    JR_Control JRControl_unit(
        .alu_op(alu_op),
        .funct(instr[5:0]),
        .JRControl(JRControl)
    );       

    // ALU control unit
    ALUControl ALU_Control_unit(
        .ALUOp(alu_op),
        .Function(instr[5:0]),
        .ALU_Control(ALU_Control)
    );  

    // Multiplexer ALU source
    assign read_data2 = (alu_src == 1'b1) ? imm_ext : reg_read_data_2;
    
    // ALU
    alu alu_unit(
        .a(reg_read_data_1),
        .b(read_data2),
        .alu_control(ALU_Control),
        .result(ALU_out),
        .zero(zero_flag)
    );  

    // Immediate shift left 2
    assign im_shift_1 = {imm_ext[29:0], 2'b00};  
    assign no_sign_ext = 32'd0;   

    // PC for branch
    assign PC_beq      = pc4 + im_shift_1;       // was conditional add/sub
    assign beq_control = branch & zero_flag;
    assign PC_4beq     = (beq_control == 1'b1) ? PC_beq : pc4;  

    // PC for jump
    assign PC_j    = {pc4[31:28], jump_shift_1}; 
    assign PC_4beqj = (jump == 1'b1) ? PC_j : PC_4beq;  
    assign PC_jr = reg_read_data_1;  

    // Next PC
    assign pc_next = (JRControl == 1'b1) ? PC_jr : PC_4beqj;  

    // Data memory
    data_memory datamem(
        .clk(clk),
        .mem_access_addr(ALU_out),
        .mem_write_data(reg_read_data_2),
        .mem_write_en(mem_write),
        .mem_read(mem_read),
        .mem_read_data(mem_read_data)
    );  

    // Write back
    assign reg_write_data = (mem_to_reg == 2'b10) ? pc4 : ((mem_to_reg == 2'b01) ? mem_read_data : ALU_out);

    // Outputs
    assign pc_out = pc_current;  
    assign alu_result = ALU_out;  

endmodule
